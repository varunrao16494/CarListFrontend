install angular
npm install -g @angular/cli

install ionic
npm install -g @ionic/cli

npm install

ionic serve