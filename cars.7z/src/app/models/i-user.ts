export interface IUser {
    mobile:number,
    token?:string
}

